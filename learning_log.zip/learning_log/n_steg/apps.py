from django.apps import AppConfig


class NStegConfig(AppConfig):
    name = 'n_steg'
